import ffmpeg

# Ejemplo de cómo usar ffmpeg-python
ffmpeg.input('input.mp4').output('output.mp4').run()
